import unittest
import sys
import os
rutaInstalacion = os.path.abspath("../HacerDoc/src")
print(rutaInstalacion)

sys.path.append(rutaInstalacion)
from LeerPdf import LeerPdf

class TestLeerPdf(unittest.TestCase):
    
    def setUp(self):
        self.pdf = LeerPdf("C:/Users/LENOVO/Documents/2023/Codigo tareas U/HacerDoc/doc/metamorfosis.pdf", 500)
        
    def test_abrirArchivo(self):
        archivo = self.pdf.abrirArchivo()
        self.assertIsNotNone(archivo)
        
    def test_leerTexto(self):
        texto = self.pdf.leerTexto()
        self.assertIsNotNone(texto)
        self.assertIsInstance(texto, str)
        
    def test_split(self):
        texts = self.pdf.split()
        self.assertIsNotNone(texts)
        self.assertIsInstance(texts, list)
        self.assertTrue(len(texts) > 0)
        
    def test_embeddings(self):
        index = self.pdf.embeddings()
        self.assertIsNotNone(index)
        self.assertEqual(index.ntotal, len(self.pdf.split()))

    

if __name__ == '__main__':
    unittest.main()