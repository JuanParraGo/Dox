import os
from langchain.vectorstores import FAISS
from langchain.text_splitter import CharacterTextSplitter
from langchain.embeddings.openai import OpenAIEmbeddings

class BuscarDocumentoSimilar:
    
    def __init__(self, embeddings_list):
        self.embeddings_list = embeddings_list
        self.docsearch = FAISS.from_vectors(embeddings_list)
        
    def buscar_similar(self, query_embedding, k=10):
        result = self.docsearch.search(query_embedding, k=k)
        return [self.embeddings_list[idx] for idx in result[0]]
    
    def guardar_pdf(self, pdf_bytes):
        titulo_pdf = self._obtener_titulo_pdf()
        ruta_pdf = os.path.abspath(f'../HacerDoc/doc/{titulo_pdf}.pdf')
        with open(ruta_pdf, 'wb') as f:
            f.write(pdf_bytes)
        return ruta_pdf
        
    def _obtener_titulo_pdf(self):
        titulo = ''
        for emb in self.embeddings_list:
            if 'pdf_title' in emb.meta_data:
                titulo = emb.meta_data['pdf_title']
                break
        return titulo
