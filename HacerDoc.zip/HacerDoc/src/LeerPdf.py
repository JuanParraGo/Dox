
from PyPDF2 import PdfReader
from langchain.text_splitter import CharacterTextSplitter
import numpy as np
import faiss
import openai
import os
import time
os.environ["OPENAI_API_KEY"] = "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"
openai.api_key= "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"
class LeerPdf:
    
    
    def __init__(self, url,chunk_size):
        self.url= url
        self.chunk_size = chunk_size
        
        


    #Abrir el archivo pdf
    def abrirArchivo(self):
        AbrirArchivo = PdfReader(self.url) 
        return AbrirArchivo
    
    #leer archivo pdf
    def leerTexto(self): 
        archivo=self.abrirArchivo()          
        raw_text = ''
        for i, page in enumerate(archivo.pages):
            text = page.extract_text()
            if text:
                raw_text += text
        return raw_text
        
    #Se parte el texto en chunks
    def split(self):
        texto= self.leerTexto() 
        text_splitter = CharacterTextSplitter(        
        separator = "\n",
        chunk_size = self.chunk_size,
        #los últimas quintas partes de caracteres del chunk actual se incluirán en el siguiente chunk
        chunk_overlap  = self.chunk_size//5,
        length_function = len,
        )
        texts = text_splitter.split_text(texto)
        return texts
    
    
    
# Organizar y almacenar datos de manera estructurada (indexar) con la biblioteca FAISS
# que se utiliza para buscar vectores en un espacio vectorial de alta dimensión,
# lo que permite realizar búsquedas rápidas y eficientes en grandes conjuntos de datos de todos los chunk
    
    def embedding(self,text,model):
            try:
                embedding = openai.Embedding.create(input=[text], model=model)['data'][0]['embedding']
                return embedding 
            except  openai.error.RateLimitError:
                print("SE ALCANZO EL LIMITE")
                time.sleep(10) 
                return  self.embedding(text,model)

    def embeddings(self):
        texts = self.split()
        # generar representaciones vectoriales de palabras y frases con OpenAI (embedding)
        model = "text-embedding-ada-002"
        embeddings = []
        for text in texts:
            text = text.replace("\n", " ")
            embedding = self.embedding(text,model)
            embeddings.append(embedding)
        embeddings = np.array(embeddings).astype('float32')
        # indexar los vectores de documentos con Faiss
        index = faiss.IndexFlatIP(embeddings.shape[1])
        index.add(embeddings)           
        return index
     
    
 
