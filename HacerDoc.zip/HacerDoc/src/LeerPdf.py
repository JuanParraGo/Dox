
from PyPDF2 import PdfReader
from langchain import FAISS
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.text_splitter import CharacterTextSplitter
import faiss
import openai
import os
import time
import numpy as np
import pandas as pd

os.environ["OPENAI_API_KEY"] = "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"
openai.api_key= "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"
class LeerPdf:
    
    
    def __init__(self, url,chunk_size):
        self.url= url
        self.chunk_size = chunk_size
        
        


    #Abrir el archivo pdf
    def abrirArchivo(self):
        AbrirArchivo = PdfReader(self.url) 
        return AbrirArchivo
    
    #leer archivo pdf
    def leerTexto(self): 
        archivo=self.abrirArchivo()          
        raw_text = ''
        for i, page in enumerate(archivo.pages):
            text = page.extract_text()
            if text:
                raw_text += text
        return raw_text
        
    #Se parte el texto en chunks
    def split(self):
        texto= self.leerTexto() 
        text_splitter = CharacterTextSplitter(        
        separator = "\n",
        chunk_size = self.chunk_size,
        #los últimas quintas partes de caracteres del chunk actual se incluirán en el siguiente chunk
        chunk_overlap  = self.chunk_size//5,
        length_function = len,
        )
        texts = text_splitter.split_text(texto)
        
        return texts
    
    
    
#Genera la vectorizacon o embedding 
    def embedding(self,text):
        model="text-embedding-ada-002"
        try:
            text = text.replace("\n", " ")
            return openai.Embedding.create(input = [text], model=model)['data'][0]['embedding']
        except openai.error.RateLimitError:
            print("reintentando en 10seg")
            time.sleep(10)
            return self.embedding(text)
        
# Entrega un df con 1 columna texto y segunda el embedding
    def dfEmbedding(self):   
         texts = self.split()  
         df = pd.DataFrame({'texto': texts})
         print(df)
         df['ada_embedding'] = df.texto.apply(lambda x: self.embedding(x))
         return df

    from openai.embeddings_utils import get_embedding, cosine_similarity

    def search_reviews(df, product_description, n=3, pprint=True):
        embedding = get_embedding(product_description, model='text-embedding-ada-002')
        df['similarities'] = df.ada_embedding.apply(lambda x: cosine_similarity(x, embedding))
        res = df.sort_values('similarities', ascending=False).head(n)
        return res
https://github.com/openai/openai-cookbook/blob/main/examples/Semantic_text_search_using_embeddings.ipynb
        res = search_reviews(df, 'delicious beans', n=3)        
            
        
        