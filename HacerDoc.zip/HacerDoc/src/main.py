import os
from LeerPdf import LeerPdf
rutaInstalacion = os.path.abspath("../HacerDoc/lib/Install.py")
os.system("python \"" + rutaInstalacion + "\"")

url = "C:/Users/LENOVO/Documents/2023/Codigo tareas U/HacerDoc/doc/metamorfosis.pdf"
kafka = LeerPdf(url,1000)
index =kafka.embeddings()
import openai
import faiss
import numpy as np

class BuscadorDeRespuestas:
    
    def __init__(self, prompt, index_path):
        openai.api_key = "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"
        self.prompt = prompt
        self.index = faiss.read_index(index_path)

    def prompt_search(self, query):
        # Generar embedding del query
        query_embedding = self.embedding(query)
        # Buscar resultados similares en el índice
        D, I = self.index.search(np.array([query_embedding]), k=1)
        # Devolver respuesta correspondiente al resultado más cercano
        return self.prompt + ' ' + self.answers[I[0][0]]
    
    def embedding(self, text):
        model = "text-embedding-ada-002"
        embedding = openai.Completion.create(
            engine=model,
            prompt=text,
            max_tokens=128,
            n=1,
            stop=None,
            temperature=0.7,
        )
        return embedding.choices[0].text

# Ejemplo de uso:
prompt = "El autor de El Quijote es"
answers = ["Miguel de Cervantes", "William Shakespeare", "Gabriel García Márquez"]
embeddings = np.array([BuscadorDeRespuestas.embedding(answer) for answer in answers])
index.add(embeddings)
buscador = BuscadorDeRespuestas(prompt, index)
query = "Quién escribió Don Quijote de la Mancha"
respuesta = buscador.prompt_search(query)
print(respuesta)