import subprocess

packages = ['langchain', 'openai', 'PyPDF2', 'faiss-cpu', 'tiktoken']

for package in packages:
    try:
        subprocess.check_call(["pip", "install", package])
        print(f"{package} instalado con éxito!")
    except subprocess.CalledProcessError as e:
        print(f"Error al instalar {package}: {str(e)}")
